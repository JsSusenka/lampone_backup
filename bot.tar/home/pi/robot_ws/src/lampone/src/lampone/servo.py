#!/usr/bin/env python3
import time
import rospy
from std_msgs.msg import String, Int32
from geometry_msgs.msg import Twist


if __name__ == "__main__":
    
    rospy.init_node("motors")
    publisher = rospy.Publisher("/cmd_vel", Twist, queue_size=10)
    time.sleep(0.2)
    cmd = Twist()
    cmd.linear.x = 0.5
    cmd.linear.y = -0.5
    publisher.publish(cmd)
    time.sleep(2)
    cmd.linear.x = 0
    publisher.publish(cmd)
    rospy.spin()