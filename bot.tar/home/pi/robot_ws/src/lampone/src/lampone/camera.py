#!/usr/bin/env python3

import numpy as np
import cv2
import cv_bridge
from sensor_msgs.msg import Image

if __name__ == "__main__":
    subscriber = rospy.Subscriber("/camera", Image, callback=imgCB, queue_size=1)    

def imgCB(msg):
    image = cv_bridge.CvBridge().bridge.imgmsg_to_cv2(msg, desired_encoding="bgr8")
    run(image)

def run(image):
    #for i in range(5):
    image2 = image[200:,:,0]
    #image_gray = cv2.cvtColor(image2, cv2.COLOR_BGR2GRAY)
    kernel = np.ones((5,5), np.float32)/25
    image_filtered = cv2.filter2D(src=image2, ddepth=-1, kernel=kernel)
    
    image_thr_blue = image[200:,:,0]>100
    image_bin_blue = np.array(image_thr_blue*255, dtype=np.uint8)
    
    image_thr_green = image[200:,:,1]>100
    image_bin_green = np.array(image_thr_green*255, dtype=np.uint8)
    
    cv2.imshow("d", image_bin_blue)
    cv2.imshow("ddd", image_bin_green)
    
    img_sum_blue = np.sum(image_bin_blue, axis=0)
    img_sum_len_blue = len(img_sum_blue)
    
    img_sum_green = np.sum(image_bin_green, axis=0)
    img_sum_len_green = len(img_sum_green)
    
    state = 0
    fIndexLeft = 0
    lIndexLeft = (img_sum_len_blue//2)
    
    fIndexRight = 0
    lIndexRight = (img_sum_len_green//2)
    
    for index, value in enumerate(img_sum_blue[0:img_sum_len_blue//2][::-1]):
        if state == 0 and value != 0:
            fIndexLeft = index
            state = 1
        elif state == 1 and value == 0:
            lIndexLeft = index
            break
     
    state = 0
    for index, value in enumerate(img_sum_green[(img_sum_len_green//2):]):
        if state == 0 and value != 0:
            fIndexRight = index
            state = 1
        elif state == 1 and value == 0:
            lIndexRight = index
            break
     
    mean_index_right = (fIndexRight + lIndexRight)/2
    mean_index_left = -(fIndexLeft + lIndexLeft)/2
    
    mean_index = (mean_index_left + mean_index_right)/2
    
    if mean_index > 10:
        servo.stop()
        servo.run("angular", 0.2)
        time.sleep(0.15)
        servo.run("angular", 0)
    elif mean_index < -10:
        servo.stop()
        servo.run("angular", -0.2)
        time.sleep(0.15)
        servo.run("angular", 0)
    elif mean_index < 40 and mean_index > 5:
        servo.left(0.6)
        time.sleep(0.3)
        servo.run("angular", 0)
    elif mean_index > -40 and mean_index < -5:
        servo.right(0.6)
        time.sleep(0.3)
        servo.run("angular", 0)
    elif mean_index < 5 and mean_index < -5:
        servo.stop()
 
 
    print(mean_index)
    display.addString(str(mean_index))
    display.push()
    
    f.write(str(mean_index))
    
    #print(center)
    
    cv2.waitKey(0)

    cv2.destroyAllWindows()

