#!/usr/bin/env python3
import time
import cv2
import rospy
from display import Display
from pyzbar.pyzbar import decode
import cv_bridge
from sensor_msgs.msg import Image
from std_msgs.msg import String, Int32
from geometry_msgs.msg import Twist
import numpy as np
from servoControler import ServoControler
from imageProccesor import proccess

class SkeletonNode:
    
    def __init__(self):
        self.bridge = cv_bridge.CvBridge()
        self.subscriber = rospy.Subscriber("/camera", Image, callback=self.imgCB, queue_size=1)
        self.servo = ServoControler()
        self.display = Display()
        self.image = None
        self.bageta = False
        self.state = "idle"
        self.direcition = "none"
        self.display.clear()
        self.displayText("Started")
    
    def imgCB(self, msg):
        self.image = self.bridge.imgmsg_to_cv2(msg, desired_encoding="bgr8")
    
    def run(self):
        while not rospy.is_shutdown():
            if self.image is None:
                continue      
            image = self.image.copy()
            image_gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            image_thr = image_gray>100
            image_bin = np.array(image_thr*255, dtype=np.uint8)
            #cv2.imshow("Frame", image_bin)
            cv2.waitKey(1)
            codes = decode(image)
            for code in codes:
                text = code.data.decode("utf-8")
                ##print(text)
                
                self.state = text
                self.stateCalc()
                time.sleep(0.4)        
            if self.bageta == True:
                proccess(self.image.copy())    
                #time.sleep(0.3)
                self.servo.run("linear", -0.45)
    
    def stateCalc(self):
        state = self.state
        self.displayText(state)
        print(state)
        if state == "dopredu":
            self.servo.run("linear", -0.5)
            time.sleep(1)
        elif state == "dozadu":
            self.servo.run("linear", 0.5)
            time.sleep(1)
        elif state == "vpravo":
            self.servo.run("angular", 0.5)
            time.sleep(1)
        elif state == "vlevo":
            self.servo.run("angular", -0.5)
            time.sleep(1)
        elif state == "otocit":
            self.servo.run("angular", 0.5)
            time.sleep(1)
            self.servo.stop()
        elif state == "stop":
            self.bageta = False
            self.servo.stop()
        elif state == "bageta":
            self.bageta = True
            self.displayText("Obrazek vyfocen")

    def displayText(self, msg):
        self.display.addString(msg)
        self.display.push()


if __name__ == "__main__":
    rospy.init_node("Skeleton")
    node = SkeletonNode()
    node.run()
    rospy.spin()    