#!/usr/bin/env python3
import time
import cv2
import rospy
from pyzbar.pyzbar import decode
import cv_bridge
from sensor_msgs.msg import Image
from std_msgs.msg import String, Int32
from geometry_msgs.msg import Twist


class ExampleNode:
    def __init__(self):
        self.bridge = cv_bridge.CvBridge()
        self.subscriber = rospy.Subscriber("/camera", Image, callback=self.image_callback, queue_size=1)
        self.publisher = publisher = rospy.Publisher("/cmd_vel", Twist, queue_size=10)
        self.image = None
        
    
    def image_callback(self, msg):
        self.image = self.bridge.imgmsg_to_cv2(msg, desired_encoding="bgr8")
        

    def run(self):
        while not rospy.is_shutdown():
            if self.image is None:
                continue
            image = self.image.copy()        
            cv2.imshow("Frame", image)
            codes = decode(image)
            for code in codes:
                text = code.data.decode("utf-8")
                print(text)
            
            if cv2.waitKey(50) & 0xFF == ord('q'):
                cv2.destroyAllWindows()
                exit(0)


if __name__ == "__main__":
    rospy.init_node("example_node")
    node = ExampleNode()
    node.run()
    rospy.spin()
