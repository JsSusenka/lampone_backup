import rospy
from geometry_msgs.msg import Twist

class ServoControler:
    
    def __init__(self):
        self.servo = rospy.Publisher("/cmd_vel", Twist, queue_size=10)
        
    def run(self, axis, velocity):
        if axis == "linear":
            message = Twist()
            message.linear.x = velocity
            self.servo.publish(message)
        elif axis == "angular":
            message = Twist()
            message.angular.z = velocity
            self.servo.publish(message)
            
    def stop(self):
        message = Twist()
        message.linear.x = 0
        message.angular.z = 0
        self.servo.publish(message)
        
    def right(self, vel):
        #self.stop()
        message = Twist()
        message.linear.x = -0.35
        message.angular.z = vel
        
     
    def left(self, vel):
        #self.stop()
        message = Twist()
        message.linear.x = -0.35
        message.angular.z = -vel