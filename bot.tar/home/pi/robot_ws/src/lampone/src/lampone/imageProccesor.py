#!/usr/bin/env python3

import rospy
import numpy as np
import cv2
import random
import time
from display import Display
from servoControler import ServoControler

servo = ServoControler()
image = None
display = Display()

f = open("/home/pi/Documents/indexlog.txt", "w")

def proccess(image):
    #for i in range(5):
    image2 = image[200:,:,0]
    #image_gray = cv2.cvtColor(image2, cv2.COLOR_BGR2GRAY)
    kernel = np.ones((5,5), np.float32)/25
    image_filtered = cv2.filter2D(src=image2, ddepth=-1, kernel=kernel)

    image_thr_blue = image[200:,:,0]>200
    image_bin_blue = np.array(image_thr_blue*255, dtype=np.uint8)
    
    ##cv2.imshow("d", image_bin_blue)
   
    img_sum_blue = np.sum(image_bin_blue, axis=0)
    img_sum_len_blue = len(img_sum_blue)
     
    fIndexRight = 0
    lIndexRight = (img_sum_len_blue//2)
    state = 0
    
    for index, value in enumerate(img_sum_blue[(img_sum_len_blue//2):]):
        if state == 0 and value != 0:
            fIndexRight = index
            state = 1
        elif state == 1 and value == 0:
            lIndexRight = index
            break
     
    mean_index_right = (fIndexRight + lIndexRight)/4
    
    if mean_index_right < 60:
        servo.run("angular", -0.35)
        time.sleep(0.15)
        servo.stop()
    elif mean_index_right > 100:
        servo.run("angular", 0.35)
        time.sleep(0.15)
        servo.stop()
    elif mean_index_right > 60:
        servo.run("linear", -0.5)
       
 
    print(mean_index_right)
    display.addString(str(mean_index_right))
    display.push()
    
    #print(center)
    
    cv2.waitKey(0)

    cv2.destroyAllWindows()
